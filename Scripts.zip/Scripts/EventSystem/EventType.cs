﻿public enum EventType
{
    ShowText,
    StartButton,
}
